# spring-boot-crud-thymeleaf
Spring Boot CRUD application with spring data jpa and thymeleaf
