package com.example.inventory.exceptions

class InsufficientStockExcpetion extends Exception{

    InsufficientStockExcpetion(String message) {
        super(message)
    }
}
