CREATE DATABASE test;
USE test;

DROP TABLE IF EXISTS `inventory`;
DROP TABLE IF EXISTS `item`;


CREATE TABLE `item` (
  'Shipper Bill No` int(11) NOT NULL AUTO_INCREMENT,
  `Shipper Name` varchar(256) UNIQUE NOT NULL,
  `Cosignee1` varchar(512) NOT NULL,
  `POD` varchar(512) NOT NULL,
  `POL` varchar(512) NOT NULL,
  `Client` varchar(256) NOT NULL,
  `Date` datetime NOT NULL,
  PRIMARY KEY (`Shipper Bill No`)
);

CREATE TABLE `test`.`inventory` (
  `Materials` INT NOT NULL,
  `count` INT NULL,
  `updated_on` DATETIME NOT NULL,
  PRIMARY KEY (`Materials`),
  CONSTRAINT `fk_inventory_1`
  FOREIGN KEY (`Materials`)
  REFERENCES `test`.`item` (`Materials`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);
